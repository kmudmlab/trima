# GPU 카운터 결과

디스플레이 프로세스가 상주한 상태에서 측정했다. 각 셀의 nvidia-smi-before.txt/xml 및 gpu-state-before.json에 프로세스 목록·GPU 전체/프로세스별 메모리 사용량·조회 시각을 보존했다. GDM 화면 프로세스만 예외로 허용했고 다른 GPU 프로세스가 있으면 대기했다.

bear에서 timing 순위 완료 뒤 application replay로 계측했다. cache-control과 clock-control은 none이다.
fixture pilot 4셀, 실그래프 profile 162셀을 통과했다.
Count에 속한 launch를 모두 수집한다. 비율은 launch별 분자·분모를 합산한 뒤 계산하고, 아래에는 독립 3 block의 중앙값을 쓴다.
Occupancy는 각 셀의 derived-metrics.json에 kernel별로 보존한다. 서로 다른 kernel의 비율을 단순 평균하지 않는다.
프로파일 wall time과 replay pass는 각 summary.json에 있으며 논문의 Count timing으로 사용하지 않는다.

| 그래프 | 계열 | L2 hit (%) | global-load sectors/request | warp execution efficiency (%) |
|---|---|---:|---:|---:|
| berkstan | steptc | 95.9609 | 1.3868 | 62.7464 |
| berkstan | tricore | 87.0675 | 1.5367 | 50.4266 |
| berkstan | trust | 99.3904 | 1.35187 | 64.7336 |
| berkstan | wetric | 100 | 3.46637 | 84.3775 |
| comlj | steptc | 87.1111 | 1.58263 | 72.2348 |
| comlj | tricore | 83.0923 | 1.83414 | 59.8862 |
| comlj | trust | 88.1174 | 1.604 | 66.4806 |
| comlj | wetric | 92.3896 | 4.76161 | 84.6854 |
| fb | steptc | 99.9994 | 1.62343 | 63.091 |
| fb | tricore | 99.9983 | 2.0836 | 61.8801 |
| fb | trust | 94.8298 | 1.62248 | 60.4178 |
| fb | wetric | 99.9985 | 4.35985 | 93.071 |
| friendster | tricore | 39.3079 | 3.49359 | 81.3259 |
| friendster | trust | 12.8495 | 1.97727 | 68.8382 |
| friendster | wetric | 34.342 | 4.4 | 92.1089 |
| google | steptc | 99.9998 | 1.28964 | 59.0618 |
| google | tricore | 97.9963 | 1.14556 | 43.8703 |
| google | trust | 99.9505 | 1.2097 | 59.8921 |
| google | wetric | 100 | 5.38061 | 66.3981 |
| hollywood | steptc | 81.1206 | 2.83901 | 65.4729 |
| hollywood | tricore | 93.256 | 3.91313 | 84.2901 |
| hollywood | trust | 92.1044 | 2.50109 | 70.4153 |
| hollywood | wetric | 93.2027 | 5.55334 | 91.2859 |
| notredame | steptc | 99.6932 | 1.32613 | 61.6394 |
| notredame | tricore | 99.9998 | 1.4622 | 50.7172 |
| notredame | trust | 99.9996 | 1.3441 | 60.9788 |
| notredame | wetric | 99.9998 | 4.30983 | 85.2318 |
| orkut | steptc | 61.1227 | 1.90613 | 73.5751 |
| orkut | tricore | 68.8211 | 2.92377 | 77.455 |
| orkut | trust | 62.794 | 1.88492 | 67.447 |
| orkut | wetric | 67.7781 | 4.36181 | 89.5288 |
| patents | steptc | 92.2212 | 1.2841 | 63.3517 |
| patents | tricore | 85.3583 | 1.14572 | 41.4946 |
| patents | trust | 94.1969 | 1.26834 | 61.6083 |
| patents | wetric | 94.9951 | 6.59452 | 69.9704 |
| skitter | steptc | 94.5407 | 1.46996 | 69.9841 |
| skitter | tricore | 90.9707 | 1.53596 | 50.4554 |
| skitter | trust | 99.6558 | 1.4815 | 65.0313 |
| skitter | wetric | 98.2181 | 4.53354 | 79.5026 |
| soclj | steptc | 85.3767 | 1.63134 | 72.6404 |
| soclj | tricore | 82.3717 | 2.0177 | 62.2608 |
| soclj | trust | 86.0401 | 1.65048 | 67.0411 |
| soclj | wetric | 90.7815 | 4.5695 | 85.5628 |
| stanford | steptc | 100 | 1.32601 | 60.901 |
| stanford | tricore | 99.9999 | 1.31082 | 48.4842 |
| stanford | trust | 99.9998 | 1.26449 | 59.7817 |
| stanford | wetric | 99.9999 | 3.92794 | 78.2052 |
| webcc | tricore | 87.6737 | 3.1699 | 85.1159 |
| webcc | trust | 80.7666 | 3.53 | 89.4642 |
| webcc | wetric | 94.7661 | 4.15017 | 98.3134 |
| wikitalk | steptc | 96.4691 | 1.63566 | 73.8727 |
| wikitalk | tricore | 96.0329 | 2.06606 | 50.583 |
| wikitalk | trust | 99.9964 | 1.6985 | 68.7247 |
| wikitalk | wetric | 100 | 5.09231 | 88.2847 |

GPU와 TT의 요청 단위는 다르다. 이 표만으로 GPU→TT 포팅 원칙의 인과관계를 확정하지 않는다.
